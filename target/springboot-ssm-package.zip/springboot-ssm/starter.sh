java -jar -Dspring.config.location=$pwd\application.properties -Dlogging.path=$pwd\log $pwd\springboot-ssm.jar
